# overview

Android 9 (API Level 28, Pie) lets you use your phone as a Bluetooth HID so you can use it as a keyboard, mouse, or joystick.

This project aims to implement Bluetooth Joystick using `BluetoothHidDevice`.

